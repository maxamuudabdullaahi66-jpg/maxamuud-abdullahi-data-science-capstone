# Project Notes

This project was built as a personalized capstone for Maxamuud Abdullahi.

The structure follows the uploaded IBM-style capstone reference: data collection, data wrangling, EDA, SQL, visual analytics, machine learning, and final reporting.

Unlike the reference project, this repository intentionally does not copy its SpaceX dataset, wording, results, or conclusions. The dataset here is synthetic and the project topic is customer churn.
