# Maxamuud Abdullahi — Customer Churn Data Science Capstone

## Project
**Customer Churn Prediction for a Somali Telecom/E-Commerce Service**

### Important dataset note
This repository uses a **synthetic educational dataset generated specifically for this capstone**. It does not represent real customers, a real company, or official statistics about Somalia.

## What is included
- 1,200 synthetic customer records
- Data cleaning workflow
- 6 Jupyter notebooks
- EDA charts
- SQL analysis
- Feature engineering
- Logistic Regression, Decision Tree, and Random Forest models
- Model evaluation
- Saved deployment pipeline
- Plotly Dash dashboard
- Final PDF report

## Main results on the synthetic test set
The exact model metrics are in `reports/model_metrics.csv`. These are only demonstrations because the underlying data are synthetic.

## Run locally

```bash
pip install -r requirements.txt
python src/data_cleaning.py
python src/train_model.py
python dashboard/app.py
```

Then open the local Dash address shown in the terminal.

## GitHub
Repository name suggestion:

`maxamuud-abdullahi-data-science-capstone`

## Author
**Maxamuud Abdullahi**
