import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html

df = pd.read_csv("../data/processed/customer_churn_clean.csv")

app = Dash(__name__)
churn_rate = df["churn"].mean()
fig_contract = px.bar(
    df.groupby("contract_type", as_index=False)["churn"].mean(),
    x="contract_type", y="churn",
    title="Churn Rate by Contract Type"
)
fig_region = px.bar(
    df.groupby("region", as_index=False)["churn"].mean(),
    x="region", y="churn",
    title="Churn Rate by Region"
)

app.layout = html.Div([
    html.H1("Customer Churn Dashboard"),
    html.H3("Maxamuud Abdullahi — Data Science Capstone"),
    html.Div([
        html.P(f"Customers: {len(df):,}"),
        html.P(f"Observed churn rate: {churn_rate:.1%}"),
    ]),
    dcc.Graph(figure=fig_contract),
    dcc.Graph(figure=fig_region),
])

if __name__ == "__main__":
    app.run(debug=True)
