-- SQL analysis for customer churn capstone
-- Adapt table name/SQL dialect as needed.

-- 1. Customer count by region
SELECT region, COUNT(*) AS customers
FROM customer_churn
GROUP BY region
ORDER BY customers DESC;

-- 2. Churn rate by contract type
SELECT contract_type,
       COUNT(*) AS customers,
       AVG(churn) AS churn_rate
FROM customer_churn
GROUP BY contract_type
ORDER BY churn_rate DESC;

-- 3. Average monthly spend by churn status
SELECT churn,
       AVG(monthly_spend_usd) AS avg_monthly_spend
FROM customer_churn
GROUP BY churn;

-- 4. Average satisfaction by churn status
SELECT churn,
       AVG(satisfaction_score) AS avg_satisfaction
FROM customer_churn
GROUP BY churn;

-- 5. Customers with repeated support interactions
SELECT customer_id, support_calls, complaints, churn
FROM customer_churn
WHERE support_calls >= 4 OR complaints >= 3
ORDER BY support_calls DESC;
