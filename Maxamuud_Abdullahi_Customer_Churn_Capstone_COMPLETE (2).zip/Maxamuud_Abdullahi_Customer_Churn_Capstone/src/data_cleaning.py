import pandas as pd

def clean_customer_data(path):
    df = pd.read_csv(path)
    df = df.drop_duplicates()
    df["satisfaction_score"] = df["satisfaction_score"].fillna(df["satisfaction_score"].median())
    df["monthly_spend_usd"] = df["monthly_spend_usd"].fillna(df["monthly_spend_usd"].median())
    df["payment_method"] = df["payment_method"].fillna(df["payment_method"].mode()[0])
    return df

if __name__ == "__main__":
    df = clean_customer_data("../data/raw/customer_churn_somalia_synthetic.csv")
    df.to_csv("../data/processed/customer_churn_clean.csv", index=False)
    print(df.shape)
