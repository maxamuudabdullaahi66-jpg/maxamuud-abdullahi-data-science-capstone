import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier

df = pd.read_csv("../data/processed/customer_churn_clean.csv")
features = ["age","gender","region","contract_type","internet_service","payment_method",
             "tenure_months","monthly_spend_usd","usage_hours_month","support_calls",
             "late_payments","satisfaction_score","discount","complaints"]
X, y = df[features], df["churn"]
num_cols = [c for c in features if df[c].dtype != "object"]
cat_cols = [c for c in features if df[c].dtype == "object"]
pre = ColumnTransformer([
    ("num", Pipeline([("imputer",SimpleImputer(strategy="median")),("scaler",StandardScaler())]), num_cols),
    ("cat", Pipeline([("imputer",SimpleImputer(strategy="most_frequent")),
                      ("onehot",OneHotEncoder(handle_unknown="ignore"))]), cat_cols)
])
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=.2,stratify=y,random_state=42)
pipe=Pipeline([("preprocessor",pre),("model",RandomForestClassifier(n_estimators=300,max_depth=8,class_weight="balanced",random_state=42))])
pipe.fit(X_train,y_train)
joblib.dump(pipe,"../models/churn_model.joblib")
print("Model saved to ../models/churn_model.joblib")
