from dash import Dash, html

app = Dash(__name__)

app.layout = html.Div([
    html.H1("Customer Churn Dashboard"),
    html.P("Maxamuud Abdullahi — Data Science Capstone"),
    html.P("TODO: Add KPI cards, charts, filters, and model insights.")
])

if __name__ == "__main__":
    app.run(debug=True)
