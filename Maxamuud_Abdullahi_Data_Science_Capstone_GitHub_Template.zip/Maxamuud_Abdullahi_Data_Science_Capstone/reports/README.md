# Final Capstone Report

Suggested sections:

1. Executive Summary
2. Introduction
3. Problem Statement
4. Objectives
5. Data Collection
6. Data Wrangling
7. Exploratory Data Analysis
8. SQL Analysis
9. Feature Engineering
10. Machine Learning
11. Model Evaluation
12. Dashboard
13. Findings
14. Limitations
15. Conclusion
16. Future Work
17. References

**Author:** Maxamuud Abdullahi
